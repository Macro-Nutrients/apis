import jwt
print(jwt.__file__)
